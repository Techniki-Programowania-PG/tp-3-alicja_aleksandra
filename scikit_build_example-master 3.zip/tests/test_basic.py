import scikit_build_example
import random

# scikit_build_example.plot_signal()

#result = scikit_build_example.generate_sin_signal(1000, 2)
# for value in result:
#     print(value)

#scikit_build_example.plot_signal(result)


# result = scikit_build_example.generate_cos_signal(1000, 2)
# scikit_build_example.plot_signal(result)


# result = scikit_build_example.generate_square_signal(1000, 10)
# scikit_build_example.plot_signal(result)


# result = scikit_build_example.generate_pilo_signal(200, 1)
# for x in result:
#     print(x)
# scikit_build_example.plot_signal(result)

# sig = [10, 8, 1, 5, 4, 10, 100, 5, 9, 1, 4, 10, 6, 10, 50, 1, 4, 5, 2]
# sig = scikit_build_example.generate_square_signal(20, 4)
# print(sig)
# scikit_build_example.plot_signal(sig)

# sig2 = scikit_build_example.filter_1d(sig)
# print(sig2)
# scikit_build_example.plot_signal(sig2)


# list_2d = []
# N = 10
# for i in range(N):
#     row = []
#     for j in range(N):
#         random_number = random.randint(1, 5)
#         row.append(random_number)
#     list_2d.append(row)

# for row in list_2d:
#     print(row)

# print("--------------------------------------")

# filtered_list = scikit_build_example.filter_2d(list_2d)
# for row in filtered_list:
#     print(row)


result = scikit_build_example.generate_sin_signal(1000, 2)
result_dft = scikit_build_example.dft(result)
print(result_dft)

idft = scikit_build_example.idft(result_dft)
print()
print(idft)
scikit_build_example.plot_signal(idft)
