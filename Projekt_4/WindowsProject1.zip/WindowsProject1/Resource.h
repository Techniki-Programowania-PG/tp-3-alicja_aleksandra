﻿#pragma once

// Tytuł aplikacji
#define IDS_APP_TITLE            103

// Główne okno
#define IDC_WINDOWSPROJECT1      109

// Menu: Plik
#define IDM_EXIT                 32772
#define IDM_SET_SPEED            32773

// Dialog: Ustaw prędkość
#define IDD_SPEED_DIALOG         130
#define IDC_SPEED_SLIDER         1001

// Menu: Filtruj figury
#define ID_FILTER_1            40001
#define ID_FILTER_2            40002
#define ID_FILTER_3            40003
#define ID_FILTER_4            40004
#define ID_FILTER_OFF          40005
